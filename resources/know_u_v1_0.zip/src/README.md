Selome Zerai
Alex Ayala
Morgan Stimpson
Justin Hanson

Group 6
Read Me

1. Download and install expo-cli with `npm install -g expo-cli@3.4.0` (See https://docs.expo.io/versions/latest/get-started/installation/ for more details)
2. Run `npm install` to install all required dependencies
3. Run `expo start` to begin running the expo tool and server
4. Download the expo app on your mobile device
5. Make sure the Expo Developer console (web gui) has connection set to "Tunnel"
6. Scan the QR code with the Expo app
7. The app should begin downloading and running on your mobile device in developer mode

Thank you for your time dear reader
