//import * as React from 'react';
//import { View, Button, Drawer } from 'react-native-paper';
//import { SimplePanel } from '../components/panel';
//
//class Menu extends React.Component {
//  state = {
//    active: 'first',
//  };
//
//return (
//            <Button>Journal</Button>
//            <Button>History</Button>
//    );
//export default Menu;
//
//   
//  }
//}
